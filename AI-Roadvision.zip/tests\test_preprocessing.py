"""
RoadVision AI - Preprocessing and Validation Unit Tests
"""

import io
import numpy as np
import pytest
from PIL import Image

from utils.preprocessing import (
    CONFIDENCE_THRESHOLD,
    DEFAULT_CLASSES,
    format_prediction_result,
    get_class_names,
    preprocess_image_for_model,
    validate_image_file
)


def test_validate_valid_jpg(valid_jpg_bytes):
    stream = io.BytesIO(valid_jpg_bytes)
    is_valid, msg = validate_image_file(stream, "road_sample.jpg")
    assert is_valid is True
    assert msg == ""


def test_validate_valid_png(valid_png_bytes):
    stream = io.BytesIO(valid_png_bytes)
    is_valid, msg = validate_image_file(stream, "pavement.png")
    assert is_valid is True
    assert msg == ""


def test_validate_invalid_extension():
    stream = io.BytesIO(b"some content")
    is_valid, msg = validate_image_file(stream, "script.py")
    assert is_valid is False
    assert "Unsupported file extension" in msg


def test_validate_empty_file():
    stream = io.BytesIO(b"")
    is_valid, msg = validate_image_file(stream, "empty.jpg")
    assert is_valid is False
    assert "empty" in msg.lower()


def test_validate_corrupted_file(corrupted_image_bytes):
    stream = io.BytesIO(corrupted_image_bytes)
    is_valid, msg = validate_image_file(stream, "bad.jpg")
    assert is_valid is False
    assert "corrupted" in msg.lower() or "invalid" in msg.lower()


def test_preprocess_image_shape_and_range(valid_jpg_bytes):
    batch_array = preprocess_image_for_model(valid_jpg_bytes)
    assert isinstance(batch_array, np.ndarray)
    assert batch_array.shape == (1, 224, 224, 3)
    # Float32 image values within [0.0, 255.0] for model graph with internal preprocessing
    assert batch_array.min() >= 0.0
    assert batch_array.max() <= 255.0


def test_format_prediction_high_confidence():
    # Simulated model output: high probability for pothole (index 2 in cracked, normal, pothole)
    probabilities = np.array([[0.05, 0.05, 0.90]])
    res = format_prediction_result(probabilities, DEFAULT_CLASSES, threshold=0.60)
    assert res["predicted_class"] == "pothole"
    assert res["predicted_display_name"] == "Pothole"
    assert res["confidence"] == pytest.approx(0.90, rel=1e-2)
    assert res["is_low_confidence"] is False
    assert "pothole" in res["interpretation"].lower()
    assert "class_scores" in res
    assert len(res["class_scores"]) == 3


def test_format_prediction_low_confidence():
    # Ambiguous prediction where max confidence is below 60%
    probabilities = np.array([[0.38, 0.35, 0.27]])
    res = format_prediction_result(probabilities, DEFAULT_CLASSES, threshold=0.60)
    assert res["is_low_confidence"] is True
    assert "low-confidence" in res["interpretation"].lower()


def test_default_class_names():
    classes = get_class_names()
    assert classes == ["cracked", "normal", "pothole"]
