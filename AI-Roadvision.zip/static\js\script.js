/**
 * RoadVision AI - Client-side UI & Prediction Handler
 * Handles drag-and-drop uploads, validation, asynchronous inference requests,
 * Chart.js probability bars, and human-in-the-loop SQLite review submissions.
 */

document.addEventListener("DOMContentLoaded", () => {
  // 1. Mobile Menu Toggle
  const menuToggle = document.getElementById("menuToggle");
  const navLinks = document.getElementById("navLinks");
  if (menuToggle && navLinks) {
    menuToggle.addEventListener("click", () => {
      navLinks.classList.toggle("mobile-open");
    });
  }

  // 2. Upload and Analysis Setup
  const dropZone = document.getElementById("dropZone");
  const fileInput = document.getElementById("fileInput");
  const previewCard = document.getElementById("previewCard");
  const previewImage = document.getElementById("previewImage");
  const previewFileName = document.getElementById("previewFileName");
  const previewFileSize = document.getElementById("previewFileSize");
  const btnAnalyze = document.getElementById("btnAnalyze");
  const btnClear = document.getElementById("btnClear");
  const spinnerContainer = document.getElementById("spinnerContainer");
  const resultContainer = document.getElementById("resultContainer");
  const alertContainer = document.getElementById("alertContainer");

  let currentSelectedFile = null;
  let activePredictionData = null;

  function showAlert(message, type = "warning") {
    if (!alertContainer) return;
    alertContainer.innerHTML = `
      <div class="alert alert-${type}">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="12" y1="8" x2="12" y2="12"></line>
          <line x1="12" y1="16" x2="12.01" y2="16"></line>
        </svg>
        <div>${message}</div>
      </div>
    `;
    alertContainer.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  function clearAlert() {
    if (alertContainer) alertContainer.innerHTML = "";
  }

  function validateFile(file) {
    if (!file) return false;
    const allowed = ["image/jpeg", "image/png", "image/webp"];
    const ext = file.name.split(".").pop().toLowerCase();
    const validExts = ["jpg", "jpeg", "png", "webp"];

    if (!validExts.includes(ext) && !allowed.includes(file.type)) {
      showAlert(`Unsupported file type: ${file.name}. Please upload a JPG, JPEG, PNG, or WEBP image.`, "danger");
      return false;
    }

    const maxBytes = 10 * 1024 * 1024; // 10 MB
    if (file.size > maxBytes) {
      showAlert(`File is too large (${(file.size / (1024 * 1024)).toFixed(1)} MB). Limit is 10 MB.`, "danger");
      return false;
    }

    clearAlert();
    return true;
  }

  function handleFileSelected(file) {
    if (!validateFile(file)) return;

    currentSelectedFile = file;
    const reader = new FileReader();

    reader.onload = (e) => {
      if (previewImage) previewImage.src = e.target.result;
      if (previewFileName) previewFileName.textContent = file.name;
      if (previewFileSize) {
        const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
        previewFileSize.textContent = `${sizeMb} MB`;
      }
      if (previewCard) previewCard.style.display = "block";
      if (resultContainer) resultContainer.style.display = "none";
      if (dropZone) dropZone.style.display = "none";
    };

    reader.readAsDataURL(file);
  }

  if (dropZone && fileInput) {
    dropZone.addEventListener("click", () => fileInput.click());

    fileInput.addEventListener("change", (e) => {
      if (e.target.files && e.target.files[0]) {
        handleFileSelected(e.target.files[0]);
      }
    });

    ["dragenter", "dragover"].forEach((eventName) => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropZone.classList.add("drag-over");
      });
    });

    ["dragleave", "drop"].forEach((eventName) => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropZone.classList.remove("drag-over");
      });
    });

    dropZone.addEventListener("drop", (e) => {
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        handleFileSelected(e.dataTransfer.files[0]);
      }
    });
  }

  if (btnClear) {
    btnClear.addEventListener("click", () => {
      currentSelectedFile = null;
      if (fileInput) fileInput.value = "";
      if (previewCard) previewCard.style.display = "none";
      if (dropZone) dropZone.style.display = "block";
      if (resultContainer) resultContainer.style.display = "none";
      clearAlert();
    });
  }

  // 3. Asynchronous Inference Execution
  if (btnAnalyze) {
    btnAnalyze.addEventListener("click", async () => {
      if (!currentSelectedFile) {
        showAlert("Please select or drop an image first.", "warning");
        return;
      }

      clearAlert();
      if (spinnerContainer) spinnerContainer.style.display = "block";
      if (btnAnalyze) btnAnalyze.disabled = true;
      if (btnClear) btnClear.disabled = true;

      const formData = new FormData();
      formData.append("image", currentSelectedFile);

      try {
        const response = await fetch("/predict", {
          method: "POST",
          headers: {
            "X-Requested-With": "XMLHttpRequest",
          },
          body: formData,
        });

        const data = await response.json();

        if (spinnerContainer) spinnerContainer.style.display = "none";
        if (btnAnalyze) btnAnalyze.disabled = false;
        if (btnClear) btnClear.disabled = false;

        if (!response.ok || !data.success) {
          showAlert(data.error || "Analysis failed. Please try again.", "danger");
          return;
        }

        // Render Results
        activePredictionData = data;
        renderPredictionResults(data);
      } catch (err) {
        if (spinnerContainer) spinnerContainer.style.display = "none";
        if (btnAnalyze) btnAnalyze.disabled = false;
        if (btnClear) btnClear.disabled = false;
        showAlert("Connection error while sending image to model backend.", "danger");
      }
    });
  }

  // 4. Render Prediction Results in UI
  function renderPredictionResults(data) {
    if (!resultContainer) return;

    resultContainer.style.display = "block";
    resultContainer.scrollIntoView({ behavior: "smooth", block: "start" });

    // Status Badge & Title
    const badgeEl = document.getElementById("resStatusBadge");
    const titleEl = document.getElementById("resPrimaryTitle");
    const interpEl = document.getElementById("resInterpretation");
    const confEl = document.getElementById("resConfidence");
    const timeEl = document.getElementById("resInferenceTime");
    const imgEl = document.getElementById("resImage");

    if (imgEl && data.image_data) {
      imgEl.src = data.image_data;
    }

    if (titleEl) titleEl.textContent = data.predicted_display_name;
    if (interpEl) interpEl.textContent = data.interpretation;
    if (confEl) confEl.textContent = `${data.confidence_percentage}%`;
    if (timeEl) timeEl.textContent = `${data.inference_time_ms} ms`;

    if (badgeEl) {
      badgeEl.className = "status-badge";
      if (data.is_low_confidence) {
        badgeEl.classList.add("badge-warning");
        badgeEl.textContent = "Low Confidence Review";
      } else {
        badgeEl.classList.add(`badge-${data.predicted_class}`);
        badgeEl.textContent = data.predicted_display_name;
      }
    }

    // Update Progress Bars for 3 classes
    const scores = data.class_scores || {};
    for (const [key, info] of Object.entries(scores)) {
      const fillEl = document.getElementById(`barFill_${key}`);
      const valEl = document.getElementById(`barVal_${key}`);
      if (fillEl) fillEl.style.width = `${info.percentage}%`;
      if (valEl) valEl.textContent = `${info.percentage}%`;
    }

    // Reset Review Box
    const reviewBox = document.getElementById("reviewActionBox");
    const reviewFeedbackMsg = document.getElementById("reviewFeedbackMsg");
    if (reviewBox) reviewBox.style.display = "block";
    if (reviewFeedbackMsg) reviewFeedbackMsg.innerHTML = "";
  }

  // 5. Human-in-the-Loop Review Handling
  const reviewButtons = document.querySelectorAll(".btn-review");
  reviewButtons.forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!activePredictionData) return;

      const verdict = btn.getAttribute("data-verdict");
      const reviewFeedbackMsg = document.getElementById("reviewFeedbackMsg");

      btn.disabled = true;

      try {
        const response = await fetch("/review", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            predicted_class: activePredictionData.predicted_class,
            confidence: activePredictionData.confidence,
            reviewer_feedback: verdict,
            notes: `Submitted via web analysis interface for image '${activePredictionData.filename}'`,
          }),
        });

        const resData = await response.json();
        if (response.ok && resData.success) {
          if (reviewFeedbackMsg) {
            reviewFeedbackMsg.innerHTML = `
              <div class="alert alert-info" style="margin-top: 14px;">
                <strong>Review Recorded:</strong> Reference ID <code>${resData.review.review_id}</code>. 
                Your feedback (${verdict.toUpperCase()}) was safely saved to the SQLite inspection log.
              </div>
            `;
          }
          // Disable all buttons in review box
          reviewButtons.forEach((b) => (b.disabled = true));
        } else {
          showAlert(resData.error || "Failed to record human review.", "warning");
          btn.disabled = false;
        }
      } catch (e) {
        showAlert("Error connecting to review database.", "danger");
        btn.disabled = false;
      }
    });
  });
});
