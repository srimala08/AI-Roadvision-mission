# Dataset Card: RoadVision AI — Road Surface Damage Benchmark

## 1. Dataset Summary

The **RoadVision AI Dataset** is a curated computer vision benchmark designed for multi-class road surface condition classification. The dataset organizes pavement imagery into three primary operational categories: **Pothole**, **Cracked Road**, and **Normal Road**.

The dataset pipeline is designed for compatibility with established international road research datasets—primarily the **Road Damage Dataset (RDD2020 / RDD2022)** curated by the University of Tokyo / Sekilab—as well as crowdsourced municipal road maintenance imagery.

---

## 2. Dataset Provenance & Metadata

| Field | Detail |
| :--- | :--- |
| **Official Name** | Road Damage Dataset (RDD2020 / RDD2022) & Crowdsourced Pavement Imagery |
| **Primary Authors / Curators** | University of Tokyo, Sekilab & Open Pavement Research Community |
| **Access Date** | October 2026 |
| **Dataset Version** | Harmonized 3-Class Road Damage Classification Benchmark v2.0 |
| **License** | [Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)](https://creativecommons.org/licenses/by-sa/4.0/) |
| **Permitted Use** | Academic research, educational capstone evaluation, and non-commercial development |
| **Repository Format** | Hierarchical directory format: `train/`, `validation/`, `test/` |

---

## 3. Class Definitions and Taxonomy Harmonization

Public road condition benchmarks frequently use detailed bounding-box taxonomies. To ensure robust image-level classification, original sub-labels are harmonized into three distinct project classes:

| Class Key | Display Name | Visual Definition | Source Taxonomy Mapping |
| :--- | :--- | :--- | :--- |
| `pothole` | **Pothole** | Distinct holes, cavities, depressions, or bowl-shaped road punctures through surface asphalt. | RDD Category **D40** (Pothole / Rutting cavity) |
| `cracked` | **Cracked Road** | Pavement fractures, linear cracks, transverse cracks, and alligator fatigue fissures. | RDD Categories **D00** (Longitudinal), **D10** (Transverse), and **D20** (Alligator) |
| `normal` | **Normal Road** | Intact, sound road surface without clearly visible potholes or major structural cracks. | Uncompromised baseline pavement imagery |

---

## 4. Dataset Preparation & Leakage Prevention

Dataset preparation follows rigorous engineering steps implemented in `prepare_dataset.py`:

1. **Format & Integrity Validation**:
   * Uses Pillow (`Image.verify()`) to decode headers and reject corrupted, truncated, or zero-byte files.
   * Restricts accepted formats to JPG, JPEG, PNG, and WEBP.

2. **Deduplication Across Splits**:
   * Computes MD5 checksums of raw image bytes to identify exact duplicate images.
   * Bars cross-split duplicates to prevent **data leakage** between the training, validation, and test sets.

3. **Reproducible Splitting**:
   * The dataset is split into:
     * **70% Training** (`dataset/train/`)
     * **15% Validation** (`dataset/validation/`)
     * **15% Testing** (`dataset/test/`)
   * Splits are created using a fixed random seed (`seed=42`) to ensure reproducible experiments.

4. **Training-Only Data Augmentation**:
   * Augmentations (slight rotations $\pm 8^\circ$, horizontal flips, moderate zoom $\pm 8\%$, contrast variations) are applied **exclusively** during training.
   * Validation and test images remain un-augmented to preserve authentic evaluation.

---

## 5. Preprocessing Specifications

* **Target Resolution**: $224 \times 224$ pixels, 3-channel RGB.
* **Aspect Ratio Handling**: Bilinear interpolation resizing.
* **Normalization**: MobileNetV2 standard normalization mapping pixel values from $[0, 255]$ to $[-1.0, 1.0]$:
  $$\hat{x} = \frac{x}{127.5} - 1.0$$

---

## 6. Known Dataset Limitations

1. **Weather & Lighting Bias**:
   * Datasets predominantly capture daytime, dry weather conditions. Heavy rain, wet pavement reflections, snow, or harsh tree shadows can reduce classification fidelity.
2. **Pavement Material Distribution**:
   * The dataset focuses primarily on bituminous asphalt and brushed concrete. Unpaved, dirt, or cobblestone surfaces may produce ambiguous predictions.
3. **No 3D Geometry**:
   * 2D RGB imagery cannot measure cavity depth, volumetric displacement, or subsurface structural failure.
4. **Class Imbalance**:
   * In municipal environments, normal roads far outnumber damaged segments. Macro-averaged metrics must be reported to evaluate minority classes fairly.

---

## 7. Instructions for Data Preparation

To audit or prepare the dataset structure, run:

```powershell
# Audit current dataset counts and check for duplicates
python prepare_dataset.py --audit

# Generate starter verification dataset (30 samples per class)
python prepare_dataset.py --generate-starter-dataset --samples-per-class 30
```
