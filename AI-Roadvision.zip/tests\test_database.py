"""
RoadVision AI - SQLite Review Database Unit Tests
"""

import pytest
from utils.database import (
    get_recent_reviews,
    get_review_statistics,
    init_db,
    save_review
)


def test_init_db(temp_db):
    assert init_db(temp_db) is True


def test_save_valid_reviews(temp_db):
    # Test valid feedback categories
    success, msg, rec1 = save_review("pothole", 0.94, "correct", notes="Clearly visible crater", db_path=temp_db)
    assert success is True
    assert rec1["reviewer_feedback"] == "correct"
    assert rec1["review_id"].startswith("REV-")

    success, msg, rec2 = save_review("cracked", 0.82, "incorrect", notes="Actually shadows from trees", db_path=temp_db)
    assert success is True
    assert rec2["reviewer_feedback"] == "incorrect"

    success, msg, rec3 = save_review("normal", 0.58, "unsure", notes="Puddle obscures surface", db_path=temp_db)
    assert success is True
    assert rec3["reviewer_feedback"] == "unsure"


def test_reject_invalid_feedback(temp_db):
    success, msg, rec = save_review("pothole", 0.90, "maybe_yes", db_path=temp_db)
    assert success is False
    assert "Invalid feedback" in msg


def test_review_statistics(temp_db):
    save_review("pothole", 0.95, "correct", db_path=temp_db)
    save_review("pothole", 0.91, "correct", db_path=temp_db)
    save_review("cracked", 0.70, "incorrect", db_path=temp_db)
    save_review("normal", 0.55, "unsure", db_path=temp_db)

    stats = get_review_statistics(temp_db)
    assert stats["total_reviews"] == 4
    assert stats["correct_count"] == 2
    assert stats["incorrect_count"] == 1
    assert stats["unsure_count"] == 1
    assert stats["agreement_rate"] == 50.0  # 2 out of 4 correct


def test_get_recent_reviews(temp_db):
    save_review("pothole", 0.92, "correct", notes="Sample 1", db_path=temp_db)
    save_review("cracked", 0.88, "correct", notes="Sample 2", db_path=temp_db)

    recent = get_recent_reviews(limit=5, db_path=temp_db)
    assert len(recent) == 2
    assert recent[0]["notes"] == "Sample 2"  # Newest first
