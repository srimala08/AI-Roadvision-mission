"""
RoadVision AI - Utility modules
"""
