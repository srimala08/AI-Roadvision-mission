"""
RoadVision AI - MobileNetV2 Transfer Learning Training Pipeline
Trains a 3-class road surface image classifier (Cracked, Normal, Pothole).
Features:
- Two-stage training: frozen feature extraction + upper layer fine-tuning
- Training-only data augmentation (rotations, flips, zoom, contrast)
- EarlyStopping and ModelCheckpoint to models/roadvision_model.keras
- Automatic detection of empty/incomplete dataset with actionable guidance
- Saves training loss and accuracy curves to reports/
- Saves canonical class mapping to models/class_indices.json
"""

import argparse
import json
import os
import sys
from typing import Dict, Tuple

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from utils.evaluation import plot_training_curves
from utils.preprocessing import DEFAULT_CLASSES

# Expected dataset paths
DATASET_DIR = os.path.join(PROJECT_ROOT, "dataset")
TRAIN_DIR = os.path.join(DATASET_DIR, "train")
VAL_DIR = os.path.join(DATASET_DIR, "validation")
MODELS_DIR = os.path.join(PROJECT_ROOT, "models")
REPORTS_DIR = os.path.join(PROJECT_ROOT, "reports")
MODEL_SAVE_PATH = os.path.join(MODELS_DIR, "roadvision_model.keras")
CLASS_INDICES_PATH = os.path.join(MODELS_DIR, "class_indices.json")

IMG_HEIGHT = 224
IMG_WIDTH = 224
BATCH_SIZE = 16


def check_dataset_readiness() -> Tuple[bool, str]:
    """Verify that dataset directories exist and contain training and validation images."""
    if not os.path.isdir(TRAIN_DIR) or not os.path.isdir(VAL_DIR):
        return False, (
            "Dataset directories missing. Ensure 'dataset/train/' and 'dataset/validation/' exist."
        )

    for split_name, split_path in [("train", TRAIN_DIR), ("validation", VAL_DIR)]:
        for cls in DEFAULT_CLASSES:
            cls_path = os.path.join(split_path, cls)
            if not os.path.isdir(cls_path):
                return False, f"Missing class directory: {cls_path}"
            images = [f for f in os.listdir(cls_path) if not f.startswith(".") and f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp'))]
            if len(images) == 0:
                return False, (
                    f"Class '{cls}' in '{split_name}' contains 0 valid images.\n"
                    f"Please place your dataset images in '{cls_path}'\n"
                    f"or run: python prepare_dataset.py --generate-starter-dataset"
                )

    return True, "Dataset ready."


def build_model(num_classes: int = 3, use_pretrained_weights: bool = True):
    """
    Constructs transfer learning model using MobileNetV2 base.
    """
    import tensorflow as tf
    from tensorflow.keras import layers, models

    weights = "imagenet" if use_pretrained_weights else None
    print(f"\n[RoadVision AI] Initializing MobileNetV2 base (weights={weights})...")

    try:
        base_model = tf.keras.applications.MobileNetV2(
            input_shape=(IMG_HEIGHT, IMG_WIDTH, 3),
            include_top=False,
            weights=weights
        )
    except Exception as e:
        print(f"\n[Warning] Could not download ImageNet weights ({e}).")
        print("[Notice] Initializing MobileNetV2 base with random initialization (weights=None).")
        base_model = tf.keras.applications.MobileNetV2(
            input_shape=(IMG_HEIGHT, IMG_WIDTH, 3),
            include_top=False,
            weights=None
        )

    # Freeze base model during initial stage
    base_model.trainable = False

    # Training data augmentation pipeline
    data_augmentation = tf.keras.Sequential([
        layers.RandomRotation(0.08),
        layers.RandomFlip("horizontal"),
        layers.RandomZoom(0.08),
        layers.RandomContrast(0.08),
    ], name="data_augmentation")

    inputs = tf.keras.Input(shape=(IMG_HEIGHT, IMG_WIDTH, 3), name="image_input")
    x = data_augmentation(inputs)
    # MobileNetV2 preprocessing maps [0, 255] to [-1, 1]
    x = tf.keras.applications.mobilenet_v2.preprocess_input(x)
    x = base_model(x, training=False)
    x = layers.GlobalAveragePooling2D(name="global_avg_pool")(x)
    x = layers.BatchNormalization(name="batch_norm")(x)
    x = layers.Dense(128, activation="relu", name="dense_features")(x)
    x = layers.Dropout(0.35, name="dropout")(x)
    outputs = layers.Dense(num_classes, activation="softmax", name="road_surface_prediction")(x)

    model = models.Model(inputs=inputs, outputs=outputs, name="RoadVision_MobileNetV2")
    return model, base_model


def train(
    epochs_stage1: int = 12,
    epochs_stage2: int = 6,
    batch_size: int = BATCH_SIZE,
    learning_rate_stage1: float = 1e-3,
    learning_rate_stage2: float = 1e-5
) -> bool:
    """Execute full transfer learning training pipeline."""
    # 1. Dataset readiness verification (runs before importing heavy ML dependencies)
    ready, message = check_dataset_readiness()
    if not ready:
        print("\n" + "!" * 65)
        print("ROADVISION AI TRAINING NOTICE: DATASET NOT READY")
        print("!" * 65)
        print(message)
        print("!" * 65 + "\n")
        return False

    # 2. Check TensorFlow installation
    try:
        import tensorflow as tf
    except ImportError:
        print("\n" + "!" * 65)
        print("ROADVISION AI NOTICE: TENSORFLOW NOT INSTALLED")
        print("!" * 65)
        print("TensorFlow is required for model training.")
        print("Please run: pip install -r requirements.txt")
        print("!" * 65 + "\n")
        return False

    os.makedirs(MODELS_DIR, exist_ok=True)
    os.makedirs(REPORTS_DIR, exist_ok=True)

    print("\n[RoadVision AI] Loading dataset...")
    train_ds = tf.keras.utils.image_dataset_from_directory(
        TRAIN_DIR,
        image_size=(IMG_HEIGHT, IMG_WIDTH),
        batch_size=batch_size,
        label_mode="categorical",
        shuffle=True,
        seed=42
    )

    val_ds = tf.keras.utils.image_dataset_from_directory(
        VAL_DIR,
        image_size=(IMG_HEIGHT, IMG_WIDTH),
        batch_size=batch_size,
        label_mode="categorical",
        shuffle=False,
        seed=42
    )

    class_names = train_ds.class_names
    print(f"[RoadVision AI] Detected classes in alphabetical order: {class_names}")

    # Save class indices mapping
    class_mapping = {name: i for i, name in enumerate(class_names)}
    with open(CLASS_INDICES_PATH, "w", encoding="utf-8") as f:
        json.dump(class_mapping, f, indent=2)
    print(f"[RoadVision AI] Saved class indices to {CLASS_INDICES_PATH}")

    # Optimize datasets for performance
    AUTOTUNE = tf.data.AUTOTUNE
    train_ds = train_ds.prefetch(buffer_size=AUTOTUNE)
    val_ds = val_ds.prefetch(buffer_size=AUTOTUNE)

    # 2. Build model
    model, base_model = build_model(num_classes=len(class_names))

    # 3. Stage 1: Train classification head
    print(f"\n--- STAGE 1: Training Classification Head ({epochs_stage1} epochs) ---")
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate_stage1),
        loss="categorical_crossentropy",
        metrics=["accuracy"]
    )

    callbacks_stage1 = [
        tf.keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=4, restore_best_weights=True, verbose=1
        ),
        tf.keras.callbacks.ModelCheckpoint(
            filepath=MODEL_SAVE_PATH, monitor="val_loss", save_best_only=True, verbose=1
        )
    ]

    history_stage1 = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=epochs_stage1,
        callbacks=callbacks_stage1
    )

    # 4. Stage 2: Fine-tuning upper layers of MobileNetV2
    history_combined = dict(history_stage1.history)
    if epochs_stage2 > 0:
        print(f"\n--- STAGE 2: Fine-Tuning Upper Layers ({epochs_stage2} epochs) ---")
        base_model.trainable = True
        # Fine-tune only the top 25 layers of MobileNetV2
        fine_tune_at = len(base_model.layers) - 25
        for layer in base_model.layers[:fine_tune_at]:
            layer.trainable = False

        model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate_stage2),
            loss="categorical_crossentropy",
            metrics=["accuracy"]
        )

        callbacks_stage2 = [
            tf.keras.callbacks.EarlyStopping(
                monitor="val_loss", patience=3, restore_best_weights=True, verbose=1
            ),
            tf.keras.callbacks.ModelCheckpoint(
                filepath=MODEL_SAVE_PATH, monitor="val_loss", save_best_only=True, verbose=1
            )
        ]

        history_stage2 = model.fit(
            train_ds,
            validation_data=val_ds,
            epochs=epochs_stage2,
            callbacks=callbacks_stage2
        )

        # Merge history
        for k in history_stage1.history.keys():
            if k in history_stage2.history:
                history_combined[k] = history_stage1.history[k] + history_stage2.history[k]

    # Save training graphs
    print(f"\n[RoadVision AI] Generating training graphs...")
    acc_path, loss_path = plot_training_curves(history_combined, REPORTS_DIR)
    print(f"  Accuracy Curve: {acc_path}")
    print(f"  Loss Curve:     {loss_path}")

    # Save raw history
    history_file = os.path.join(REPORTS_DIR, "training_history.json")
    with open(history_file, "w", encoding="utf-8") as f:
        json.dump(history_combined, f, indent=2)

    # Ensure best model is saved
    model.save(MODEL_SAVE_PATH)
    print(f"\n[SUCCESS] Model successfully trained and saved to: {MODEL_SAVE_PATH}")
    return True


def main():
    parser = argparse.ArgumentParser(description="Train RoadVision AI MobileNetV2 Classifier")
    parser.add_argument("--epochs-head", type=int, default=12, help="Epochs for Stage 1 head training")
    parser.add_argument("--epochs-finetune", type=int, default=6, help="Epochs for Stage 2 fine-tuning")
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE, help="Training batch size")
    args = parser.parse_args()

    success = train(
        epochs_stage1=args.epochs_head,
        epochs_stage2=args.epochs_finetune,
        batch_size=args.batch_size
    )
    if not success:
        sys.exit(1)


if __name__ == "__main__":
    main()
