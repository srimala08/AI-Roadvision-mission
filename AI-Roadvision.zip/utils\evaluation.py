"""
RoadVision AI - Model Evaluation and Visualization Utility
Computes classification metrics (Accuracy, Precision, Recall, F1-Score, Confusion Matrix)
and generates visual reports (confusion matrix heatmap, loss and accuracy curves).
"""

import json
import os
from typing import Dict, List, Optional, Tuple
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend for headless server execution
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    precision_recall_fscore_support
)

try:
    import seaborn as sns
    HAS_SEABORN = True
except ImportError:
    HAS_SEABORN = False


def calculate_metrics(
    y_true: List[int],
    y_pred: List[int],
    class_names: List[str]
) -> Dict:
    """
    Computes overall accuracy, macro-averaged and per-class precision, recall, and f1.
    """
    acc = accuracy_score(y_true, y_pred)
    macro_p, macro_r, macro_f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="macro", zero_division=0
    )
    weighted_p, weighted_r, weighted_f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="weighted", zero_division=0
    )

    per_class_p, per_class_r, per_class_f1, per_class_support = precision_recall_fscore_support(
        y_true, y_pred, average=None, zero_division=0, labels=list(range(len(class_names)))
    )

    cm = confusion_matrix(y_true, y_pred, labels=list(range(len(class_names))))

    per_class_metrics = {}
    for i, name in enumerate(class_names):
        per_class_metrics[name] = {
            "precision": round(float(per_class_p[i]), 4),
            "recall": round(float(per_class_r[i]), 4),
            "f1_score": round(float(per_class_f1[i]), 4),
            "support": int(per_class_support[i])
        }

    return {
        "accuracy": round(float(acc), 4),
        "macro_precision": round(float(macro_p), 4),
        "macro_recall": round(float(macro_r), 4),
        "macro_f1": round(float(macro_f1), 4),
        "weighted_precision": round(float(weighted_p), 4),
        "weighted_recall": round(float(weighted_r), 4),
        "weighted_f1": round(float(weighted_f1), 4),
        "total_test_samples": int(len(y_true)),
        "per_class": per_class_metrics,
        "confusion_matrix": cm.tolist(),
        "class_names": class_names
    }


def plot_confusion_matrix_chart(
    cm_array: np.ndarray,
    class_display_names: List[str],
    output_path: str
) -> bool:
    """
    Plots a confusion matrix heatmap and saves to output_path.
    """
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    plt.figure(figsize=(7, 6))

    if HAS_SEABORN:
        sns.heatmap(
            cm_array,
            annot=True,
            fmt="d",
            cmap="Blues",
            xticklabels=class_display_names,
            yticklabels=class_display_names,
            cbar=True,
            annot_kws={"size": 13, "weight": "bold"}
        )
    else:
        # Fallback to standard matplotlib imshow
        plt.imshow(cm_array, interpolation="nearest", cmap=plt.cm.Blues)
        plt.colorbar()
        tick_marks = np.arange(len(class_display_names))
        plt.xticks(tick_marks, class_display_names, rotation=25)
        plt.yticks(tick_marks, class_display_names)
        thresh = cm_array.max() / 2.0
        for i in range(cm_array.shape[0]):
            for j in range(cm_array.shape[1]):
                plt.text(
                    j, i, format(cm_array[i, j], "d"),
                    horizontalalignment="center",
                    color="white" if cm_array[i, j] > thresh else "black",
                    weight="bold"
                )

    plt.title("RoadVision AI - Confusion Matrix", fontsize=14, pad=15, weight="bold")
    plt.ylabel("True Class", fontsize=12)
    plt.xlabel("Predicted Class", fontsize=12)
    plt.tight_layout()
    plt.savefig(output_path, dpi=160)
    plt.close()
    return True


def plot_training_curves(history: Dict, reports_dir: str) -> Tuple[str, str]:
    """
    Plots training and validation accuracy and loss curves from training history dictionary.
    Saves:
      - reports_dir/training_accuracy.png
      - reports_dir/training_loss.png
    """
    os.makedirs(reports_dir, exist_ok=True)
    acc_path = os.path.join(reports_dir, "training_accuracy.png")
    loss_path = os.path.join(reports_dir, "training_loss.png")

    epochs = range(1, len(history.get("accuracy", [])) + 1)

    # 1. Accuracy Plot
    plt.figure(figsize=(8, 5))
    plt.plot(epochs, history.get("accuracy", []), marker="o", color="#0284c7", linewidth=2, label="Training Accuracy")
    if "val_accuracy" in history:
        plt.plot(epochs, history.get("val_accuracy", []), marker="s", color="#0d9488", linewidth=2, label="Validation Accuracy")
    plt.title("Model Accuracy over Epochs", fontsize=13, weight="bold")
    plt.xlabel("Epoch", fontsize=11)
    plt.ylabel("Accuracy", fontsize=11)
    plt.ylim([0.0, 1.05])
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(acc_path, dpi=160)
    plt.close()

    # 2. Loss Plot
    plt.figure(figsize=(8, 5))
    plt.plot(epochs, history.get("loss", []), marker="o", color="#e11d48", linewidth=2, label="Training Loss")
    if "val_loss" in history:
        plt.plot(epochs, history.get("val_loss", []), marker="s", color="#ea580c", linewidth=2, label="Validation Loss")
    plt.title("Model Loss over Epochs", fontsize=13, weight="bold")
    plt.xlabel("Epoch", fontsize=11)
    plt.ylabel("Loss", fontsize=11)
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(loss_path, dpi=160)
    plt.close()

    return acc_path, loss_path


def load_saved_metrics(reports_dir: str) -> Dict:
    """
    Loads saved evaluation metrics from reports_dir/evaluation_metrics.json.
    Returns dictionary with available=True or available=False.
    """
    metrics_file = os.path.join(reports_dir, "evaluation_metrics.json")
    if not os.path.isfile(metrics_file):
        return {
            "available": False,
            "message": "Evaluation not yet performed. Run 'python evaluate_model.py' to generate metrics."
        }

    try:
        with open(metrics_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        data["available"] = True
        return data
    except Exception as e:
        return {
            "available": False,
            "message": f"Could not read evaluation metrics: {str(e)}"
        }
