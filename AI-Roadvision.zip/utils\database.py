"""
RoadVision AI - SQLite Review Database Module
Manages human-in-the-loop inspection records.
Stores reviewer feedback separately from training datasets.
No personal data, vehicle registration plates, or permanent user images are stored.
"""

import os
import sqlite3
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Tuple

DATABASE_FILE = "reviews.db"


def get_db_path(base_dir: Optional[str] = None) -> str:
    """Return absolute path to reviews.db."""
    if base_dir:
        return os.path.join(base_dir, DATABASE_FILE)
    return os.path.abspath(DATABASE_FILE)


def init_db(db_path: Optional[str] = None) -> bool:
    """
    Initializes the SQLite database schema if not already present.
    Returns True on success, raises RuntimeError on failure.
    """
    target_path = db_path or get_db_path()
    try:
        conn = sqlite3.connect(target_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS human_reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                review_id TEXT UNIQUE NOT NULL,
                predicted_class TEXT NOT NULL,
                confidence REAL NOT NULL,
                reviewer_feedback TEXT NOT NULL,
                notes TEXT,
                timestamp TEXT NOT NULL
            )
        """)
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        raise RuntimeError(f"Failed to initialize SQLite review database at {target_path}: {e}")


def save_review(
    predicted_class: str,
    confidence: float,
    reviewer_feedback: str,
    notes: Optional[str] = None,
    db_path: Optional[str] = None
) -> Tuple[bool, str, Dict]:
    """
    Inserts a human reviewer verdict into the SQLite database.
    Feedback options: 'correct', 'incorrect', 'unsure'
    Returns (success: bool, message: str, review_record: dict)
    """
    valid_feedback = {"correct", "incorrect", "unsure"}
    feedback_clean = reviewer_feedback.strip().lower()
    if feedback_clean not in valid_feedback:
        return False, f"Invalid feedback value '{reviewer_feedback}'. Must be one of: {list(valid_feedback)}", {}

    target_path = db_path or get_db_path()
    review_id = f"REV-{uuid.uuid4().hex[:8].upper()}"
    timestamp_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

    try:
        init_db(target_path)
        conn = sqlite3.connect(target_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO human_reviews (
                review_id, predicted_class, confidence, reviewer_feedback, notes, timestamp
            ) VALUES (?, ?, ?, ?, ?, ?)
        """, (
            review_id,
            predicted_class,
            float(confidence),
            feedback_clean,
            (notes or "").strip()[:500],  # Sanitize and limit notes length
            timestamp_str
        ))
        conn.commit()
        conn.close()

        record = {
            "review_id": review_id,
            "predicted_class": predicted_class,
            "confidence": round(float(confidence), 4),
            "reviewer_feedback": feedback_clean,
            "notes": notes or "",
            "timestamp": timestamp_str
        }
        return True, "Review feedback successfully recorded.", record
    except Exception as e:
        return False, f"Database error saving review: {str(e)}", {}


def get_review_statistics(db_path: Optional[str] = None) -> Dict:
    """
    Returns summary statistics of reviewer submissions.
    """
    target_path = db_path or get_db_path()
    stats = {
        "total_reviews": 0,
        "correct_count": 0,
        "incorrect_count": 0,
        "unsure_count": 0,
        "agreement_rate": 0.0,
        "available": False
    }

    if not os.path.isfile(target_path):
        return stats

    try:
        conn = sqlite3.connect(target_path)
        cursor = conn.cursor()
        cursor.execute("SELECT reviewer_feedback, COUNT(*) FROM human_reviews GROUP BY reviewer_feedback")
        rows = cursor.fetchall()

        total = 0
        for feedback_type, count in rows:
            total += count
            if feedback_type == "correct":
                stats["correct_count"] = count
            elif feedback_type == "incorrect":
                stats["incorrect_count"] = count
            elif feedback_type == "unsure":
                stats["unsure_count"] = count

        stats["total_reviews"] = total
        stats["available"] = True
        if total > 0:
            stats["agreement_rate"] = round((stats["correct_count"] / total) * 100, 1)

        conn.close()
    except Exception:
        pass

    return stats


def get_recent_reviews(limit: int = 10, db_path: Optional[str] = None) -> List[Dict]:
    """Retrieve the most recent human review submissions."""
    target_path = db_path or get_db_path()
    if not os.path.isfile(target_path):
        return []

    try:
        conn = sqlite3.connect(target_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("""
            SELECT review_id, predicted_class, confidence, reviewer_feedback, notes, timestamp
            FROM human_reviews
            ORDER BY id DESC LIMIT ?
        """, (limit,))
        rows = cursor.fetchall()
        results = [dict(row) for row in rows]
        conn.close()
        return results
    except Exception:
        return []
