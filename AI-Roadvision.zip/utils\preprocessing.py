"""
RoadVision AI - Image Preprocessing and Validation Utility
Provides image integrity verification, dimensions resizing, MobileNetV2 normalization,
and consistent class label mapping across training, evaluation, and inference.
"""

import io
import json
import os
from typing import Dict, List, Optional, Tuple
import numpy as np
from PIL import Image

# Allowed image extensions and max size
ALLOWED_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.webp'}
MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024  # 10 MB
TARGET_IMAGE_SIZE = (224, 224)

# Canonical 3-class definitions (sorted alphabetically to match Keras default)
DEFAULT_CLASSES = ["cracked", "normal", "pothole"]

CLASS_DISPLAY_NAMES = {
    "cracked": "Cracked Road",
    "normal": "Normal Road",
    "pothole": "Pothole"
}

CLASS_DESCRIPTIONS = {
    "pothole": "Visible holes, cavities, or depressions in the road surface.",
    "cracked": "Visible cracks, fissures, or fractures on the road surface.",
    "normal": "Road surface without clearly visible potholes or significant cracks."
}

CLASS_INTERPRETATIONS = {
    "pothole": "The model detected visual features consistent with a pothole. Please inspect the image to confirm the result.",
    "cracked": "The model detected visual features consistent with road cracking. Manual inspection is recommended.",
    "normal": "The model classified this image as a normal road surface. This does not guarantee that the road is free of defects."
}

CONFIDENCE_THRESHOLD = 0.60  # 60% confidence threshold for review flagging


def get_class_names(class_indices_path: Optional[str] = None) -> List[str]:
    """
    Load class names from class_indices.json if available; otherwise return DEFAULT_CLASSES.
    """
    if class_indices_path and os.path.isfile(class_indices_path):
        try:
            with open(class_indices_path, "r", encoding="utf-8") as f:
                mapping = json.load(f)
            # mapping can be {class_name: index} or {index: class_name}
            if mapping and isinstance(next(iter(mapping.values())), int):
                sorted_classes = sorted(mapping.keys(), key=lambda k: mapping[k])
                return sorted_classes
            elif mapping and isinstance(next(iter(mapping.keys())), (int, str)):
                sorted_classes = [mapping[str(i)] for i in range(len(mapping))]
                return sorted_classes
        except Exception:
            pass
    return list(DEFAULT_CLASSES)


def validate_image_file(file_stream, filename: str) -> Tuple[bool, str]:
    """
    Validates uploaded file extension, size, and image content integrity.
    Returns (is_valid, error_message).
    """
    if not filename:
        return False, "No file selected."

    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        return False, f"Unsupported file extension '{ext}'. Please upload JPG, JPEG, PNG, or WEBP."

    # Check file size by reading stream into memory
    file_bytes = file_stream.read()
    if len(file_bytes) == 0:
        return False, "Uploaded file is empty (0 bytes)."
    if len(file_bytes) > MAX_FILE_SIZE_BYTES:
        max_mb = MAX_FILE_SIZE_BYTES // (1024 * 1024)
        return False, f"File exceeds the maximum allowed size of {max_mb} MB."

    # Validate image format and integrity using Pillow
    try:
        with Image.open(io.BytesIO(file_bytes)) as img:
            img.verify()  # Verifies image header and stream integrity
    except Exception as e:
        return False, f"Corrupted or invalid image file: {str(e)}"

    # Reset stream pointer so subsequent calls can read the data
    file_stream.seek(0)
    return True, ""


def preprocess_image_for_model(image_input) -> np.ndarray:
    """
    Prepares an image for MobileNetV2 inference:
    1. Loads from filepath, bytes, or PIL Image.
    2. Converts to RGB (handles RGBA / Grayscale).
    3. Resizes to 224 x 224 pixels with bilinear/bicubic interpolation.
    4. Applies MobileNetV2 normalization: scales pixel values to [-1, 1] range:
       (pixel / 127.5) - 1.0.
    5. Expands dimensions to (1, 224, 224, 3) batch shape.
    """
    if isinstance(image_input, (str, bytes, io.BytesIO)):
        if isinstance(image_input, bytes):
            image_input = io.BytesIO(image_input)
        img = Image.open(image_input)
    elif isinstance(image_input, Image.Image):
        img = image_input
    else:
        raise ValueError(f"Unsupported image input type: {type(image_input)}")

    # Ensure 3-channel RGB
    if img.mode != "RGB":
        img = img.convert("RGB")

    # Resize to MobileNetV2 standard dimensions
    img_resized = img.resize(TARGET_IMAGE_SIZE, Image.Resampling.BILINEAR)

    # Convert to float32 numpy array
    img_array = np.asarray(img_resized, dtype=np.float32)

    # MobileNetV2 model contains an internal preprocess_input layer,
    # so input tensor should be in standard [0.0, 255.0] float32 range.
    batch_array = np.expand_dims(img_array, axis=0)
    return batch_array


def format_prediction_result(
    probabilities: np.ndarray,
    class_names: Optional[List[str]] = None,
    threshold: float = CONFIDENCE_THRESHOLD
) -> Dict:
    """
    Formats the raw model probability output into an interpretable prediction dictionary.
    """
    if class_names is None:
        class_names = DEFAULT_CLASSES

    # Flatten if batch dimension present
    if probabilities.ndim > 1:
        probs = probabilities[0].tolist()
    else:
        probs = probabilities.tolist()

    class_scores = {}
    for i, class_key in enumerate(class_names):
        score = float(probs[i]) if i < len(probs) else 0.0
        display_name = CLASS_DISPLAY_NAMES.get(class_key, class_key.title())
        class_scores[class_key] = {
            "key": class_key,
            "display_name": display_name,
            "score": score,
            "percentage": round(score * 100, 2),
            "description": CLASS_DESCRIPTIONS.get(class_key, "")
        }

    # Best prediction
    predicted_idx = int(np.argmax(probs))
    predicted_key = class_names[predicted_idx]
    confidence = float(probs[predicted_idx])
    is_low_confidence = confidence < threshold

    if is_low_confidence:
        interpretation = (
            f"Low-confidence result ({confidence * 100:.1f}%): the image features are ambiguous "
            f"or difficult for the model to classify reliably. Please review it manually."
        )
    else:
        interpretation = CLASS_INTERPRETATIONS.get(
            predicted_key,
            f"Model predicted {CLASS_DISPLAY_NAMES.get(predicted_key, predicted_key)}."
        )

    return {
        "predicted_class": predicted_key,
        "predicted_display_name": CLASS_DISPLAY_NAMES.get(predicted_key, predicted_key.title()),
        "confidence": confidence,
        "confidence_percentage": round(confidence * 100, 2),
        "is_low_confidence": is_low_confidence,
        "threshold_used": threshold,
        "interpretation": interpretation,
        "class_scores": class_scores
    }
