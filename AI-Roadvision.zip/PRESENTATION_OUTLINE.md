# Capstone Presentation Outline: RoadVision AI

**Project Title**: ROADVISION AI — Intelligent Road Surface & Pothole Detection System  
**Track**: AI & Machine Learning Second-Year Capstone Project  
**Presenter**: AI/ML Student Engineering Team  
**Format**: 10-Slide Oral Presentation & Live Demonstration  

---

## Slide 1: Title & Project Vision
* **Title**: RoadVision AI: Intelligent Road Surface & Pothole Detection System
* **Subtitle**: Automated Pavement Distress Classification via MobileNetV2 Deep Transfer Learning
* **Visual**: Project identity logo with teal accents and transportation tech motif
* **Presenter Script**:
  > "Good morning, evaluators and peers. Today we present RoadVision AI, an intelligent computer vision system that classifies road surface damage into three distinct categories—Potholes, Cracked Roads, and Normal Roads—using MobileNetV2 transfer learning, coupled with an empirical human-in-the-loop review workflow."

---

## Slide 2: The Problem: Scalable Road Maintenance
* **The Challenge**:
  * Potholes and asphalt fractures cause billions in vehicle damage and present severe traffic safety hazards.
  * Manual road surveying is slow, labor-intensive, hazardous for field workers, and difficult to scale across thousands of road kilometers.
* **The Question**:
  * Can lightweight deep learning reliably classify visible pavement defects from single-view digital photographs, and how should ambiguous cases be safely handled?

---

## Slide 3: The Proposed Solution
* **Three-Class Surface Condition Taxonomy**:
  1. **Pothole**: Localized cavity or bowl-shaped road surface puncture.
  2. **Cracked Road**: Linear, transverse, or interconnected alligator fractures.
  3. **Normal Road**: Uncompromised, sound pavement without visible defect signatures.
* **Design Philosophy**:
  * Lightweight inference (<100ms) suitable for mobile/edge devices.
  * Honest evaluation with zero fabricated scores.
  * Automatic flagging for human review when model confidence falls below 60%.

---

## Slide 4: Dataset Provenance & Leakage Prevention
* **Data Source**: Road Damage Dataset (RDD2020 / RDD2022) & Crowdsourced Pavement Imagery under CC BY-SA 4.0.
* **Taxonomy Harmonization**: Mapping complex bounding box labels (D00, D10, D20, D40) to standard 3-class image taxonomy.
* **Data Leakage Mitigation**:
  * MD5 byte checksum deduplication across dataset splits.
  * Strict partitioning: 70% Training, 15% Validation, 15% Testing.
  * Data augmentation (rotations, flips, zoom, contrast) applied **strictly** to training data.

---

## Slide 5: Deep Learning Architecture
* **Backbone**: MobileNetV2 (Pretrained on ImageNet).
  * Inverted residual bottleneck blocks.
  * Depthwise separable convolutions (~3.5M parameters vs. ResNet-50's ~25M).
* **Custom Classification Head**:
  * `GlobalAveragePooling2D()`
  * `BatchNormalization()`
  * `Dense(128, activation='relu')`
  * `Dropout(0.35)` (prevents feature co-adaptation)
  * `Dense(3, activation='softmax')` (three-class output distribution)

---

## Slide 6: Two-Stage Training Methodology
* **Stage 1 (Feature Extraction)**:
  * Frozen MobileNetV2 base; optimize top head with Adam ($\text{lr} = 10^{-3}$).
* **Stage 2 (Fine-Tuning)**:
  * Unfreeze top 25 depthwise residual layers; train with low learning rate ($\text{lr} = 10^{-5}$).
* **Regularization & Artifacts**:
  * `EarlyStopping` on validation loss (patience = 4).
  * `ModelCheckpoint` saves best model to `models/roadvision_model.keras`.
  * Generates real accuracy and loss curves in `reports/`.

---

## Slide 7: Model Evaluation & Error Analysis
* **Why Macro-Averaging Matters**:
  * Overall accuracy hides minority class weakness. We compute Macro Precision, Macro Recall, and Macro F1-score across all 3 classes.
* **Confusion Matrix Analysis**:
  * Evaluating true positives, false positives, and cross-class confusion.
  * Observed confusion: Linear cracks occasionally confused with thin tree shadows.
* **Confidence Gating**:
  * Samples with top prediction score $< 60\%$ are flagged as "Low-Confidence Review" requiring manual inspection.

---

## Slide 8: Human-in-the-Loop Review System
* **Closing the AI Loop**:
  * Real-world infrastructure systems must empower human oversight.
* **Field Verification Interface**:
  * Inspectors review classification and submit feedback: *Correct*, *Incorrect*, or *Unsure*.
* **Isolated SQLite Storage**:
  * Reviews stored in `reviews.db` with unique review IDs.
  * Decoupled from model training data to prevent unverified feedback from corrupting model weights.

---

## Slide 9: Responsible AI, Limitations & Privacy
* **Critical Operational Limitations**:
  * 2D visual classification only—cannot measure pothole depth, volume, or sub-base integrity.
  * Environmental factors (glare, rain, shadows) affect visual accuracy.
  * Not a substitute for a licensed civil engineer's official inspection.
* **Privacy by Design**:
  * No persistent user image retention on the server.
  * No vehicle license plates or biometric identity data collected.
  * WCAG 2.1 accessible interface with high contrast and keyboard navigation.

---

## Slide 10: Future Roadmap & Live Demonstration
* **Future Developments**:
  * Multimodal fusion: Combining camera imagery with vehicle accelerometer / gyroscope vibration data.
  * Stereo camera / LiDAR depth estimation for volumetric crater measurement.
  * Model quantization to TensorFlow Lite for sub-watt edge microcontroller deployment (ESP32-CAM / Raspberry Pi).
* **Live System Demo**:
  * Uploading test pavement images.
  * Viewing real-time MobileNetV2 classification and probability distributions.
  * Submitting human verification feedback to SQLite.
