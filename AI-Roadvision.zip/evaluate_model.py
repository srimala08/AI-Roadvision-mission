"""
RoadVision AI - Model Evaluation and Error Analysis Script
Evaluates the trained MobileNetV2 model on the unseen test set (dataset/test).
Computes Accuracy, Macro-averaged Precision, Recall, F1, Per-class breakdown,
Confusion Matrix Heatmap, and False Positive / False Negative error inspection.
"""

import argparse
import json
import os
import sys
from typing import Dict, List, Tuple
import numpy as np

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from utils.evaluation import calculate_metrics, plot_confusion_matrix_chart
from utils.preprocessing import CLASS_DISPLAY_NAMES, DEFAULT_CLASSES, get_class_names

MODEL_PATH = os.path.join(PROJECT_ROOT, "models", "roadvision_model.keras")
CLASS_INDICES_PATH = os.path.join(PROJECT_ROOT, "models", "class_indices.json")
TEST_DIR = os.path.join(PROJECT_ROOT, "dataset", "test")
REPORTS_DIR = os.path.join(PROJECT_ROOT, "reports")
METRICS_JSON_PATH = os.path.join(REPORTS_DIR, "evaluation_metrics.json")
CM_PNG_PATH = os.path.join(REPORTS_DIR, "confusion_matrix.png")


def check_prerequisites() -> Tuple[bool, str]:
    """Verify model and test set exist before evaluation."""
    if not os.path.isfile(MODEL_PATH):
        return False, (
            f"Trained model not found at '{MODEL_PATH}'.\n"
            "Please train the model first by running:\n"
            "  python train_model.py"
        )

    if not os.path.isdir(TEST_DIR):
        return False, f"Test directory '{TEST_DIR}' not found."

    total_test_images = 0
    for cls in DEFAULT_CLASSES:
        cls_dir = os.path.join(TEST_DIR, cls)
        if os.path.isdir(cls_dir):
            imgs = [f for f in os.listdir(cls_dir) if not f.startswith(".") and f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp'))]
            total_test_images += len(imgs)

    if total_test_images == 0:
        return False, (
            f"No test images found in '{TEST_DIR}'.\n"
            "Please populate the test set with images or run:\n"
            "  python prepare_dataset.py --generate-starter-dataset"
        )

    return True, "Prerequisites satisfied."


def evaluate() -> bool:
    """Run evaluation and produce metrics and charts."""
    ready, msg = check_prerequisites()
    if not ready:
        print("\n" + "!" * 65)
        print("ROADVISION AI EVALUATION NOTICE")
        print("!" * 65)
        print(msg)
        print("!" * 65 + "\n")
        return False

    try:
        import tensorflow as tf
    except ImportError:
        print("\n" + "!" * 65)
        print("ROADVISION AI NOTICE: TENSORFLOW NOT INSTALLED")
        print("!" * 65)
        print("TensorFlow is required for evaluation.")
        print("Please run: pip install -r requirements.txt")
        print("!" * 65 + "\n")
        return False

    print(f"\n[RoadVision AI] Loading trained model from: {MODEL_PATH}")
    try:
        model = tf.keras.models.load_model(MODEL_PATH)
    except Exception as e:
        print(f"[Error] Failed to load model file: {e}")
        return False

    class_names = get_class_names(CLASS_INDICES_PATH)
    print(f"[RoadVision AI] Using class mapping: {class_names}")

    print(f"[RoadVision AI] Loading test dataset from: {TEST_DIR}")
    test_ds = tf.keras.utils.image_dataset_from_directory(
        TEST_DIR,
        image_size=(224, 224),
        batch_size=16,
        shuffle=False,
        label_mode="int"
    )

    y_true: List[int] = []
    y_pred: List[int] = []
    y_scores: List[List[float]] = []

    print("[RoadVision AI] Running inference on test images...")
    for images, labels in test_ds:
        preds = model.predict(images, verbose=0)
        predicted_classes = np.argmax(preds, axis=1)

        y_true.extend(labels.numpy().tolist())
        y_pred.extend(predicted_classes.tolist())
        y_scores.extend(preds.tolist())

    y_true_arr = np.array(y_true)
    y_pred_arr = np.array(y_pred)

    # Calculate metrics
    metrics = calculate_metrics(y_true_arr.tolist(), y_pred_arr.tolist(), class_names)

    # Plot and save confusion matrix
    display_names = [CLASS_DISPLAY_NAMES.get(c, c.title()) for c in class_names]
    cm_arr = np.array(metrics["confusion_matrix"])
    plot_confusion_matrix_chart(cm_arr, display_names, CM_PNG_PATH)
    print(f"[RoadVision AI] Saved confusion matrix heatmap to: {CM_PNG_PATH}")

    # Inspect error cases (false positives and false negatives)
    error_cases = []
    for idx, (true_lbl, pred_lbl) in enumerate(zip(y_true, y_pred)):
        if true_lbl != pred_lbl:
            error_cases.append({
                "sample_index": idx,
                "true_class": class_names[true_lbl],
                "predicted_class": class_names[pred_lbl],
                "confidence": round(float(y_scores[idx][pred_lbl]), 4)
            })

    metrics["error_analysis"] = {
        "total_misclassifications": len(error_cases),
        "misclassification_rate": round(len(error_cases) / len(y_true), 4) if len(y_true) > 0 else 0.0,
        "sample_errors": error_cases[:10]  # Store first 10 for inspection
    }

    # Save metrics JSON
    with open(METRICS_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    print(f"[RoadVision AI] Saved evaluation metrics to: {METRICS_JSON_PATH}")

    # Print summary report
    print("\n" + "=" * 65)
    print("ROADVISION AI — TEST EVALUATION REPORT")
    print("=" * 65)
    print(f"Total Test Images: {metrics['total_test_samples']}")
    print(f"Overall Accuracy:  {metrics['accuracy'] * 100:.2f}%")
    print(f"Macro Precision:   {metrics['macro_precision'] * 100:.2f}%")
    print(f"Macro Recall:      {metrics['macro_recall'] * 100:.2f}%")
    print(f"Macro F1-Score:    {metrics['macro_f1'] * 100:.2f}%")
    print("-" * 65)
    print(f"{'Class':<15} | {'Precision':<10} | {'Recall':<10} | {'F1-Score':<10} | {'Support':<8}")
    print("-" * 65)
    for c in class_names:
        c_stats = metrics["per_class"][c]
        d_name = CLASS_DISPLAY_NAMES.get(c, c)
        print(
            f"{d_name:<15} | "
            f"{c_stats['precision']*100:>8.1f}% | "
            f"{c_stats['recall']*100:>8.1f}% | "
            f"{c_stats['f1_score']*100:>8.1f}% | "
            f"{c_stats['support']:>8}"
        )
    print("-" * 65)
    print(f"Misclassified Test Images: {len(error_cases)} / {len(y_true)}")
    if error_cases:
        print("\nSample Misclassification Patterns:")
        for err in error_cases[:5]:
            print(f"  - True '{err['true_class']}' misclassified as '{err['predicted_class']}' (confidence: {err['confidence']*100:.1f}%)")
    print("=" * 65 + "\n")

    return True


def main():
    parser = argparse.ArgumentParser(description="Evaluate RoadVision AI Classifier on Test Set")
    parser.parse_args()
    success = evaluate()
    if not success:
        sys.exit(1)


if __name__ == "__main__":
    main()
