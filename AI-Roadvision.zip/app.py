"""
RoadVision AI - Intelligent Road Surface & Pothole Detection System
Flask Web Application Backend
"""

import base64
import io
import json
import os
import sys
import time
from datetime import datetime
from typing import Optional
from flask import (
    Flask,
    jsonify,
    redirect,
    render_template,
    request,
    send_from_directory,
    url_for
)
from werkzeug.utils import secure_filename

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from utils.database import get_db_path, get_recent_reviews, get_review_statistics, init_db, save_review
from utils.evaluation import load_saved_metrics
from utils.preprocessing import (
    CLASS_DISPLAY_NAMES,
    DEFAULT_CLASSES,
    MAX_FILE_SIZE_BYTES,
    format_prediction_result,
    get_class_names,
    preprocess_image_for_model,
    validate_image_file
)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "roadvision-secure-key-2026")
app.config["MAX_CONTENT_LENGTH"] = MAX_FILE_SIZE_BYTES

MODEL_PATH = os.path.join(PROJECT_ROOT, "models", "roadvision_model.keras")
CLASS_INDICES_PATH = os.path.join(PROJECT_ROOT, "models", "class_indices.json")
REPORTS_DIR = os.path.join(PROJECT_ROOT, "reports")
DATASET_DIR = os.path.join(PROJECT_ROOT, "dataset")

# Global reference to loaded model (lazy loaded or initialized)
_CACHED_MODEL = None


def get_model():
    """Lazy loader for TensorFlow/Keras model."""
    global _CACHED_MODEL
    if _CACHED_MODEL is not None:
        return _CACHED_MODEL

    if not os.path.isfile(MODEL_PATH):
        return None

    try:
        import tensorflow as tf
        _CACHED_MODEL = tf.keras.models.load_model(MODEL_PATH)
        return _CACHED_MODEL
    except Exception as e:
        app.logger.error(f"Error loading model from {MODEL_PATH}: {e}")
        return None


def get_model_status_info():
    """Inspects actual model presence and metadata."""
    is_trained = os.path.isfile(MODEL_PATH)
    file_size_mb = 0.0
    last_modified = None

    if is_trained:
        stat = os.stat(MODEL_PATH)
        file_size_mb = round(stat.st_size / (1024 * 1024), 2)
        last_modified = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")

    class_names = get_class_names(CLASS_INDICES_PATH)
    metrics = load_saved_metrics(REPORTS_DIR)

    return {
        "is_available": is_trained,
        "model_path": "models/roadvision_model.keras" if is_trained else None,
        "file_size_mb": file_size_mb,
        "last_modified": last_modified,
        "architecture": "MobileNetV2 (Transfer Learning)",
        "classes": class_names,
        "class_display_names": [CLASS_DISPLAY_NAMES.get(c, c.title()) for c in class_names],
        "test_accuracy": metrics.get("accuracy") if metrics.get("available") else None,
        "evaluation_available": metrics.get("available", False)
    }


def get_dataset_stats_info():
    """Inspects actual image counts in dataset/ splits."""
    stats = {"train": 0, "validation": 0, "test": 0, "total": 0}
    for split in ["train", "validation", "test"]:
        split_path = os.path.join(DATASET_DIR, split)
        if os.path.isdir(split_path):
            count = 0
            for root, _, files in os.walk(split_path):
                for f in files:
                    if not f.startswith(".") and f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp')):
                        count += 1
            stats[split] = count
    stats["total"] = stats["train"] + stats["validation"] + stats["test"]
    return stats


# Initialize SQLite database on startup
try:
    init_db(get_db_path(PROJECT_ROOT))
except Exception as e:
    app.logger.warning(f"Could not initialize SQLite DB on launch: {e}")


# ---------------------------------------------------------
# ROUTES
# ---------------------------------------------------------

@app.route("/")
def index():
    """Homepage: Hero section, features, workflow, real stats."""
    model_status = get_model_status_info()
    dataset_stats = get_dataset_stats_info()
    review_stats = get_review_statistics(get_db_path(PROJECT_ROOT))
    return render_template(
        "index.html",
        model_status=model_status,
        dataset_stats=dataset_stats,
        review_stats=review_stats
    )


@app.route("/analyze")
def analyze():
    """Image analysis interface."""
    model_status = get_model_status_info()
    return render_template("analyze.html", model_status=model_status)


@app.route("/predict", methods=["POST"])
def predict():
    """
    Accepts an image file upload, validates integrity and size,
    preprocesses image for MobileNetV2, runs genuine model inference,
    and returns prediction results.
    """
    start_time = time.time()

    # Check model availability first
    model = get_model()
    if model is None:
        error_msg = (
            "Model is not yet trained or available. "
            "Please train the model using 'python train_model.py' before analyzing images."
        )
        if request.headers.get("X-Requested-With") == "XMLHttpRequest" or request.is_json:
            return jsonify({"success": False, "error": error_msg, "code": "MODEL_UNAVAILABLE"}), 503
        return render_template("results.html", error=error_msg, model_available=False), 503

    if "image" not in request.files:
        error_msg = "No image file provided in upload request."
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify({"success": False, "error": error_msg}), 400
        return render_template("results.html", error=error_msg), 400

    file = request.files["image"]
    filename = secure_filename(file.filename or "")

    # Validate image file
    is_valid, validation_err = validate_image_file(file.stream, filename)
    if not is_valid:
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify({"success": False, "error": validation_err}), 400
        return render_template("results.html", error=validation_err), 400

    try:
        # Read file bytes for base64 display preview
        file_bytes = file.read()
        b64_image = f"data:image/jpeg;base64,{base64.b64encode(file_bytes).decode('utf-8')}"

        # Preprocess image
        input_tensor = preprocess_image_for_model(file_bytes)

        # Run genuine model inference
        raw_predictions = model.predict(input_tensor, verbose=0)
        class_names = get_class_names(CLASS_INDICES_PATH)

        # Format formatted prediction result
        result = format_prediction_result(raw_predictions, class_names)
        inference_time_ms = round((time.time() - start_time) * 1000, 1)

        result.update({
            "success": True,
            "filename": filename,
            "inference_time_ms": inference_time_ms,
            "timestamp": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
            "image_data": b64_image
        })

        if request.headers.get("X-Requested-With") == "XMLHttpRequest" or request.content_type == "application/json":
            return jsonify(result)

        return render_template("results.html", prediction=result, model_available=True)

    except Exception as e:
        app.logger.error(f"Prediction error: {str(e)}")
        error_msg = "An unexpected error occurred while analyzing the image. Please verify image integrity."
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify({"success": False, "error": error_msg}), 500
        return render_template("results.html", error=error_msg), 500


@app.route("/results")
def results_page():
    """Direct result page view fallback."""
    return redirect(url_for("analyze"))


@app.route("/dataset")
def dataset_page():
    """Technical workflow, dataset specifications, and evaluation results."""
    model_status = get_model_status_info()
    dataset_stats = get_dataset_stats_info()
    metrics = load_saved_metrics(REPORTS_DIR)
    return render_template(
        "dataset.html",
        model_status=model_status,
        dataset_stats=dataset_stats,
        metrics=metrics
    )


@app.route("/about")
def about_page():
    """About project, responsible AI, accessibility, privacy, and limitations."""
    model_status = get_model_status_info()
    return render_template("about.html", model_status=model_status)


@app.route("/review", methods=["POST"])
def submit_review():
    """
    Submits a human reviewer verdict (correct, incorrect, unsure)
    into the SQLite database.
    """
    data = request.get_json(silent=True) or request.form
    predicted_class = data.get("predicted_class", "").strip()
    feedback = data.get("reviewer_feedback", "").strip()
    notes = data.get("notes", "").strip()

    try:
        confidence = float(data.get("confidence", 0.0))
    except (ValueError, TypeError):
        return jsonify({"success": False, "error": "Invalid confidence value"}), 400

    if not predicted_class or not feedback:
        return jsonify({"success": False, "error": "Missing predicted_class or reviewer_feedback"}), 400

    success, message, record = save_review(
        predicted_class=predicted_class,
        confidence=confidence,
        reviewer_feedback=feedback,
        notes=notes,
        db_path=get_db_path(PROJECT_ROOT)
    )

    if not success:
        return jsonify({"success": False, "error": message}), 400

    return jsonify({"success": True, "message": message, "review": record}), 201


@app.route("/api/model-status")
def api_model_status():
    """Returns actual model training status and metrics."""
    return jsonify(get_model_status_info())


@app.route("/api/evaluation")
def api_evaluation():
    """Returns saved test evaluation metrics."""
    metrics = load_saved_metrics(REPORTS_DIR)
    return jsonify(metrics)


@app.route("/reports/<path:filename>")
def serve_report_file(filename):
    """Safely serves generated evaluation charts."""
    return send_from_directory(REPORTS_DIR, filename)


# Error Handlers
@app.errorhandler(413)
def file_too_large(e):
    msg = f"File is too large. Maximum allowed upload size is {MAX_FILE_SIZE_BYTES // (1024*1024)} MB."
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"success": False, "error": msg}), 413
    return render_template("results.html", error=msg), 413


@app.errorhandler(404)
def not_found(e):
    return render_template("index.html", error="Page not found."), 404


@app.errorhandler(500)
def server_error(e):
    return jsonify({"success": False, "error": "Internal server error."}), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"\n==================================================")
    print(f" ROADVISION AI — Web Server Starting on http://127.0.0.1:{port}")
    print(f"==================================================")
    app.run(host="127.0.0.1", port=port, debug=False)
