"""
RoadVision AI - Flask Routes and API Integration Tests
"""

import io
import json
from unittest.mock import MagicMock, patch
import numpy as np
import pytest


def test_homepage_route(client):
    response = client.get("/")
    assert response.status_code == 200
    html = response.data.decode("utf-8")
    assert "ROADVISION AI" in html
    assert "See the Road" in html
    assert "Analyze an Image" in html


def test_analyze_route(client):
    response = client.get("/analyze")
    assert response.status_code == 200
    html = response.data.decode("utf-8")
    assert "Analyze Road Surface Image" in html
    assert "dropZone" in html


def test_dataset_route(client):
    response = client.get("/dataset")
    assert response.status_code == 200
    html = response.data.decode("utf-8")
    assert "Dataset &amp; Deep Learning Architecture" in html
    assert "MobileNetV2" in html


def test_about_route(client):
    response = client.get("/about")
    assert response.status_code == 200
    html = response.data.decode("utf-8")
    assert "Responsible Machine Learning" in html
    assert "Eight Critical Model" in html


def test_api_model_status(client):
    response = client.get("/api/model-status")
    assert response.status_code == 200
    data = json.loads(response.data)
    assert "is_available" in data
    assert "classes" in data
    assert len(data["classes"]) == 3


def test_api_evaluation(client):
    response = client.get("/api/evaluation")
    assert response.status_code == 200
    data = json.loads(response.data)
    assert "available" in data


def test_predict_model_unavailable(client, valid_jpg_bytes):
    # When model is None, /predict should return 503 without crashing
    with patch("app.get_model", return_value=None):
        data = {
            "image": (io.BytesIO(valid_jpg_bytes), "road.jpg")
        }
        response = client.post(
            "/predict",
            data=data,
            content_type="multipart/form-data",
            headers={"X-Requested-With": "XMLHttpRequest"}
        )
        assert response.status_code == 503
        res_json = json.loads(response.data)
        assert res_json["success"] is False
        assert "not yet trained" in res_json["error"].lower()


def test_predict_invalid_extension(client):
    # Mock model present
    mock_model = MagicMock()
    with patch("app.get_model", return_value=mock_model):
        data = {
            "image": (io.BytesIO(b"fake content"), "test.exe")
        }
        response = client.post(
            "/predict",
            data=data,
            content_type="multipart/form-data",
            headers={"X-Requested-With": "XMLHttpRequest"}
        )
        assert response.status_code == 400
        res_json = json.loads(response.data)
        assert "Unsupported file extension" in res_json["error"]


def test_predict_corrupted_image(client, corrupted_image_bytes):
    mock_model = MagicMock()
    with patch("app.get_model", return_value=mock_model):
        data = {
            "image": (io.BytesIO(corrupted_image_bytes), "road.jpg")
        }
        response = client.post(
            "/predict",
            data=data,
            content_type="multipart/form-data",
            headers={"X-Requested-With": "XMLHttpRequest"}
        )
        assert response.status_code == 400
        res_json = json.loads(response.data)
        assert "Corrupted" in res_json["error"] or "invalid" in res_json["error"].lower()


def test_predict_successful_inference(client, valid_jpg_bytes):
    # Mock model predict method returning probabilities [0.08, 0.12, 0.80] (Pothole)
    mock_model = MagicMock()
    mock_model.predict.return_value = np.array([[0.08, 0.12, 0.80]])

    with patch("app.get_model", return_value=mock_model):
        data = {
            "image": (io.BytesIO(valid_jpg_bytes), "sample_pothole.jpg")
        }
        response = client.post(
            "/predict",
            data=data,
            content_type="multipart/form-data",
            headers={"X-Requested-With": "XMLHttpRequest"}
        )
        assert response.status_code == 200
        res_json = json.loads(response.data)
        assert res_json["success"] is True
        assert res_json["predicted_class"] == "pothole"
        assert res_json["predicted_display_name"] == "Pothole"
        assert res_json["confidence_percentage"] == 80.0
        assert res_json["is_low_confidence"] is False
        assert "class_scores" in res_json


def test_submit_human_review(client):
    payload = {
        "predicted_class": "pothole",
        "confidence": 0.88,
        "reviewer_feedback": "correct",
        "notes": "Verified visually during field inspection"
    }
    response = client.post(
        "/review",
        json=payload
    )
    assert response.status_code == 201
    data = json.loads(response.data)
    assert data["success"] is True
    assert "review" in data
    assert data["review"]["review_id"].startswith("REV-")
