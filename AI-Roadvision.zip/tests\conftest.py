"""
RoadVision AI - Pytest Test Fixtures
Provides synthetic image fixtures and test clients for isolated testing.
"""

import io
import os
import sys
import tempfile
import pytest
from PIL import Image
import numpy as np

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app import app
from utils.database import init_db


@pytest.fixture
def client():
    """Flask test client."""
    app.config["TESTING"] = True
    app.config["WTF_CSRF_ENABLED"] = False
    with app.test_client() as client:
        yield client


@pytest.fixture
def valid_jpg_bytes():
    """Creates a real in-memory JPEG test image (100x100)."""
    img = Image.new("RGB", (100, 100), color=(80, 85, 90))
    buffer = io.BytesIO()
    img.save(buffer, format="JPEG")
    buffer.seek(0)
    return buffer.getvalue()


@pytest.fixture
def valid_png_bytes():
    """Creates a real in-memory PNG test image (100x100)."""
    img = Image.new("RGB", (100, 100), color=(50, 60, 70))
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    buffer.seek(0)
    return buffer.getvalue()


@pytest.fixture
def corrupted_image_bytes():
    """Generates non-image invalid bytes."""
    return b"CORRUPTED_NON_IMAGE_DATA_1234567890"


@pytest.fixture
def temp_db():
    """Provides a temporary SQLite database for review testing."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    init_db(path)
    yield path
    if os.path.exists(path):
        os.remove(path)
