# Final Project Report: RoadVision AI — Intelligent Road Surface & Pothole Detection System

**Author**: AI & Machine Learning Capstone Student  
**Academic Level**: Second-Year Capstone Project  
**Date**: October 2026  
**Repository**: `roadvision-ai/`  
**License**: CC BY-SA 4.0 / MIT Academic License  

---

## Executive Summary

Road infrastructure deterioration poses significant public safety hazards, increases vehicle repair expenditures, and compounds municipal maintenance budgets. Traditional manual pavement inspections are time-consuming, subjective, and difficult to scale across thousands of kilometers of roadway.

**RoadVision AI** is an intelligent, automated road surface image classification system designed to detect and categorize visible pavement damage from standard 2D digital imagery. Using deep transfer learning with the **MobileNetV2** convolutional neural network, the system classifies road surfaces into three key operational states:
1. **Pothole** (localized structural cavities and depressions)
2. **Cracked Road** (linear, transverse, and alligator fatigue fractures)
3. **Normal Road** (sound pavement without clearly visible defect signatures)

The application incorporates an end-to-end processing pipeline, including strict data leakage prevention, training-only data augmentation, early stopping, macro-averaged statistical evaluation, and a transparent **human-in-the-loop review workflow** backed by SQLite.

---

## 1. Problem Definition & Objectives

### 1.1 Problem Statement
Municipalities and transport authorities struggle with timely identification of road distress. How can deep transfer learning identify visible road damage from digital imagery with high computational efficiency, and how should uncertain or ambiguous cases be managed responsibly?

### 1.2 Core Project Objectives
* **Technical Rigor**: Implement genuine transfer learning using MobileNetV2 with real backpropagation rather than heuristic or hardcoded predictions.
* **Leakage-Free Data Protocol**: Prevent data contamination across training, validation, and test splits using MD5 checksum deduplication.
* **Responsible Classification**: Implement confidence gating (<60% confidence threshold) to automatically triage ambiguous samples for human review.
* **Usable Interface**: Deliver a modern, responsive web application (Flask + HTML5/CSS3/JavaScript) adhering to WCAG 2.1 accessibility and data privacy principles.

---

## 2. Dataset Collection, Harmonization & Provenance

### 2.1 Source and Licensing
The project utilizes road surface benchmark data compatible with the **Road Damage Dataset (RDD2020 / RDD2022)** published by the University of Tokyo / Sekilab under Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0).

### 2.2 Taxonomy Harmonization
Benchmark bounding-box labels are mapped to image-level single-label categories:
* **RDD D40** $\rightarrow$ `pothole`
* **RDD D00, D10, D20** $\rightarrow$ `cracked`
* **Undamaged road segments** $\rightarrow$ `normal`

### 2.3 Split Methodology & Leakage Prevention
Images are partitioned into:
* **70% Training**
* **15% Validation**
* **15% Testing**

To prevent misleading evaluation results caused by near-duplicate burst images, `prepare_dataset.py` computes MD5 perceptual hashes across splits. Any duplicate is purged, ensuring that test metrics reflect true generalization performance.

---

## 3. Deep Learning Architecture & Training Pipeline

### 3.1 Model Selection: Why MobileNetV2?
MobileNetV2 was selected as the deep learning backbone due to its architectural suitability for edge and field deployments:
1. **Inverted Residual Blocks**: Enhances gradient flow and reduces memory footprint.
2. **Depthwise Separable Convolutions**: Drastically reduces parameter count (~3.5M parameters) compared to ResNet-50 (~25M) or VGG-16 (~138M) while maintaining competitive feature representation.
3. **Sub-100ms Inference Latency**: Enables fast inference on consumer hardware and potential future deployment to vehicle dashcams.

### 3.2 Preprocessing Pipeline
* Input image resolution resized to $224 \times 224 \times 3$ RGB.
* Pixel intensity scaled to $[-1.0, 1.0]$ via MobileNetV2 preprocessing:
  $$x_{\text{norm}} = \frac{x}{127.5} - 1.0$$

### 3.3 Training Strategy: Two-Stage Transfer Learning
1. **Stage 1 (Feature Extraction)**:
   * The pretrained MobileNetV2 convolutional base is frozen (`trainable = False`).
   * A custom dense head is trained with Adam optimizer ($\text{lr} = 10^{-3}$):
     * `GlobalAveragePooling2D()`
     * `BatchNormalization()`
     * `Dense(128, activation='relu')`
     * `Dropout(0.35)`
     * `Dense(3, activation='softmax')`
2. **Stage 2 (Fine-Tuning)**:
   * The top 25 depthwise residual layers of MobileNetV2 are unfrozen.
   * Fine-tuning is executed with a conservative learning rate ($\text{lr} = 10^{-5}$) to adapt high-level feature maps to specific pavement textures without destroying pretrained generic representations.
3. **Regularization & Callbacks**:
   * `EarlyStopping(monitor='val_loss', patience=4, restore_best_weights=True)` prevents overfitting.
   * `ModelCheckpoint` saves the best model state to `models/roadvision_model.keras`.
   * Training-only data augmentation (rotations $\pm 8\%$, horizontal flips, zoom $\pm 8\%$, contrast adjustment) enforces invariance to camera orientation and lighting variations.

---

## 4. Evaluation Methodology & Metrics

### 4.1 Evaluation Criteria
Road damage datasets exhibit natural class imbalance (normal road surfaces typically outnumber severe potholes). Therefore, overall accuracy alone is insufficient. The system reports:
* **Overall Accuracy**
* **Macro-Averaged Precision, Recall, and F1-Score** (weights each class equally regardless of sample frequency)
* **Per-Class Metrics**:
  * Pothole Precision / Recall / F1
  * Cracked Road Precision / Recall / F1
  * Normal Road Precision / Recall / F1
* **Empirical Confusion Matrix**: Plots true labels vs. predicted labels.

### 4.2 Error Analysis
False positives and false negatives are systematically logged during evaluation:
* **Cracks vs. Shadows**: Overcast shadows from utility poles or roadside trees can share spatial frequency characteristics with linear cracks.
* **Potholes vs. Road Debris / Water**: Surface puddles or dark pavement patches can occasionally be confused with shallow depressions.
* **Mitigation**: The system's 60% confidence gate flags these borderline instances as **Low-Confidence Results**, directing them to human inspectors.

---

## 5. Human-in-the-Loop Review System

To prevent automated AI over-reliance, RoadVision AI integrates a human verification module:
1. **Review Options**: After every classification, field inspectors can indicate:
   * **Prediction Appears Correct**
   * **Prediction Appears Incorrect**
   * **Unsure / Requires Field Inspection**
2. **Isolated Storage**: Feedback is stored in a dedicated SQLite database (`reviews.db`) with fields `review_id`, `predicted_class`, `confidence`, `reviewer_feedback`, and `timestamp`.
3. **Data Integrity**: Reviewer feedback is never automatically merged into training data without independent engineering validation, protecting the model from biased user submissions.

---

## 6. Responsible AI, Ethics & Privacy

### 6.1 Eight Critical Operational Limitations
1. **2D Surface Features Only**: The model does not measure pavement sub-base durability, structural deflection, or vehicle driveability.
2. **Environmental Sensitivity**: Heavy rain, glare, low light, and oblique camera perspectives reduce classification accuracy.
3. **Pavement Material Bias**: Performance is calibrated for asphalt and brushed concrete; unpaved gravel or cobblestone roads are out-of-domain.
4. **Normal Road Predictions Do Not Guarantee Safety**: Absence of visible damage in the field of view does not preclude subsurface structural issues.
5. **No Volumetric Measurements**: 2D images cannot establish pothole depth or volume.
6. **Not an Engineering Substitute**: The system is an automated triage tool and cannot replace a certified civil engineer's on-site inspection.
7. **Softmax Output Calibration**: Softmax probabilities reflect distribution confidence, not absolute real-world truth.
8. **Class Imbalance**: Minority class performance must be audited with macro-averaged metrics.

### 6.2 Data Privacy Protections
* **Zero Permanent Image Storage**: Uploaded inspection images are processed in-memory and not permanently retained on disk.
* **No PII or License Plate Harvesting**: The system does not extract, track, or index vehicle license plates or pedestrian faces.
* **WCAG 2.1 Accessibility**: High color contrast (>4.5:1), keyboard navigation, and multi-channel status indicators ensure accessibility for all users.

---

## 7. Future Work

1. **Multimodal Sensor Fusion**: Integrating smartphone accelerometer/gyroscope signals with camera feeds to correlate visual surface defects with physical vehicle vibration.
2. **Stereo Depth & LiDAR Integration**: Employing depth sensors to quantify 3D pothole volume and crater depth.
3. **Edge Optimization**: Quantizing the MobileNetV2 model to TensorFlow Lite (int8) for sub-watt execution on embedded microcontrollers (Raspberry Pi / ESP32-CAM) directly mounted on municipal vehicles.

---

## 8. Conclusion

RoadVision AI demonstrates a functional, academically rigorous machine learning capstone. By combining MobileNetV2 transfer learning with honest evaluation protocols, data leakage prevention, and a human-in-the-loop verification pipeline, the project bridges the gap between theoretical deep learning and practical infrastructure inspection.
